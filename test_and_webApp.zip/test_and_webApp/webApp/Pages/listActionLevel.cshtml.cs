﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace webApp.Pages;

public class listActionLevelModel : PageModel
{
    private readonly ILogger<listActionLevelModel> _logger;

    public listActionLevelModel(ILogger<listActionLevelModel> logger)
    {
        _logger = logger;
    }

    public void OnGet()
    {

    }
}
